#include <iostream>
using namespace std;

int main() {
    int numero;
    unsigned long long fatorial = 1;

    cout << "Digite um numero: ";
    cin >> numero;

    if (numero < 0) {
        cout << "Nao existe fatorial de numero negativo." << endl;
    }
    else if (numero > 20) {
        cout << "Numero muito grande para calcular." << endl;
    }
    else {
        for (int i = 1; i <= numero; i++) {
            fatorial *= i;
        }

        cout << "O fatorial de " << numero
             << " e: " << fatorial << endl;
    }

    return 0;
}
