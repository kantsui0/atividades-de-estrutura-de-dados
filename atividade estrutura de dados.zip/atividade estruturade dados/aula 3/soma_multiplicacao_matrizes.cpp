#include <iostream>
using namespace std;

int main() {
    int A[10][10], B[10][10];
    int soma[10][10], multiplicacao[10][10];
    int linhas, colunas;

    cout << "Digite o numero de linhas: ";
    cin >> linhas;

    cout << "Digite o numero de colunas: ";
    cin >> colunas;

    if (linhas < 1 || linhas > 10 || colunas < 1 || colunas > 10) {
        cout << "Dimensoes invalidas. Use valores entre 1 e 10.\\n";
        return 1;
    }

    cout << "\\nDigite os elementos da matriz A:\\n";
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            cin >> A[i][j];
        }
    }

    cout << "\\nDigite os elementos da matriz B:\\n";
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            cin >> B[i][j];
        }
    }

    // Soma das matrizes
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            soma[i][j] = A[i][j] + B[i][j];
        }
    }

    // Multiplicacao das matrizes
    // Este algoritmo pressupoe matrizes quadradas.
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            multiplicacao[i][j] = 0;
            for (int k = 0; k < colunas; k++) {
                multiplicacao[i][j] += A[i][k] * B[k][j];
            }
        }
    }

    cout << "\\nResultado da soma:\\n";
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            cout << soma[i][j] << " ";
        }
        cout << endl;
    }

    cout << "\\nResultado da multiplicacao:\\n";
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            cout << multiplicacao[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
