#include <stdio.h>
#include <stdlib.h>

#define CAPACIDADE 5

int fila[CAPACIDADE];
int inicio = 0;
int fim = 0;
int quantidade = 0;

int isEmpty(void) {
    return quantidade == 0;
}

int isFull(void) {
    return quantidade == CAPACIDADE;
}

void enqueue(int valor) {
    if (isFull()) {
        printf("A fila esta cheia! Nao e possivel inserir.\n");
        return;
    }

    fila[fim] = valor;
    fim = (fim + 1) % CAPACIDADE;
    quantidade++;
    printf("Elemento %d inserido na fila.\n", valor);
}

void dequeue(void) {
    if (isEmpty()) {
        printf("A fila esta vazia! Nao ha elemento para remover.\n");
        return;
    }

    printf("Elemento %d removido da fila.\n", fila[inicio]);
    inicio = (inicio + 1) % CAPACIDADE;
    quantidade--;
}

void mostrarFila(void) {
    int i;

    if (isEmpty()) {
        printf("A fila esta vazia.\n");
        return;
    }

    printf("Fila (inicio -> fim): ");
    for (i = 0; i < quantidade; i++) {
        printf("%d ", fila[(inicio + i) % CAPACIDADE]);
    }
    printf("\n");
}

int main(void) {
    int opcao;
    int valor;

    do {
        printf("\n===== MENU DA FILA =====\n");
        printf("1 - Enfileirar (inserir)\n");
        printf("2 - Desenfileirar (remover)\n");
        printf("3 - Mostrar fila\n");
        printf("4 - Sair\n");
        printf("Escolha uma opcao: ");

        if (scanf("%d", &opcao) != 1) {
            printf("Entrada invalida. Encerrando o programa.\n");
            return 1;
        }

        switch (opcao) {
            case 1:
                if (isFull()) {
                    printf("A fila esta cheia! Nao e possivel inserir.\n");
                } else {
                    printf("Digite o valor para inserir: ");
                    if (scanf("%d", &valor) != 1) {
                        printf("Valor invalido. Encerrando o programa.\n");
                        return 1;
                    }
                    enqueue(valor);
                }
                break;
            case 2:
                dequeue();
                break;
            case 3:
                mostrarFila();
                break;
            case 4:
                printf("Programa encerrado.\n");
                break;
            default:
                printf("Opcao invalida. Escolha de 1 a 4.\n");
        }
    } while (opcao != 4);

    return 0;
}
