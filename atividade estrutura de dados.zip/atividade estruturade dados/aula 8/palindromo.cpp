
#include <iostream>
using namespace std;

int main() {
    char palavra[100];
    int inicio = 0;
    int fim = 0;
    bool palindromo = true;

    cout << "Digite uma palavra: ";
    cin >> palavra;

    // Descobre o tamanho da palavra
    while (palavra[fim] != '\0') {
        fim++;
    }

    fim--;

    // Compara o primeiro e o ultimo caractere
    while (inicio < fim) {

        if (palavra[inicio] != palavra[fim]) {
            palindromo = false;
            break;
        }

        inicio++;
        fim--;
    }

    // Resultado
    if (palindromo) {
        cout << "A palavra e um PALINDROMO!" << endl;
    } else {
        cout << "A palavra NAO e um PALINDROMO!" << endl;
    }

    return 0;
}
