
#include <iostream>
using namespace std;

class Pilha {
private:
    int* elementos;
    int topo;
    int capacidade;

public:
    // Construtor
    Pilha(int tamanho) {
        capacidade = tamanho;
        elementos = new int[capacidade];
        topo = -1;
    }

    // Verifica se a pilha esta vazia
    bool estaVazia() {
        return topo == -1;
    }

    // Verifica se a pilha esta cheia
    bool estaCheia() {
        return topo == capacidade - 1;
    }

    // Insere um elemento na pilha
    void inserir(int valor) {
        if (estaCheia()) {
            cout << "A pilha esta cheia! Nao e possivel inserir.\n";
        } else {
            topo++;
            elementos[topo] = valor;
            cout << "Elemento " << valor << " inserido!\n";
        }
    }

    // Remove o elemento do topo
    void remover() {
        if (estaVazia()) {
            cout << "A pilha esta vazia! Nao e possivel remover.\n";
        } else {
            cout << "Elemento removido: " << elementos[topo] << endl;
            topo--;
        }
    }

    // Mostra os elementos da pilha
    void mostrar() {
        if (estaVazia()) {
            cout << "Pilha vazia!\n";
        } else {
            cout << "Elementos da pilha (topo para base): ";

            for (int i = topo; i >= 0; i--) {
                cout << elementos[i] << " ";
            }

            cout << endl;
        }
    }

    // Destrutor
    ~Pilha() {
        delete[] elementos;
    }
};

int main() {
    int tamanho;
    int valor;

    cout << "Digite o tamanho maximo da pilha: ";
    cin >> tamanho;

    if (tamanho <= 0) {
        cout << "Tamanho invalido!\n";
        return 0;
    }

    Pilha pilha(tamanho);

    // Inserindo N-1 elementos
    cout << "\nDigite " << tamanho - 1
         << " elementos para a pilha:\n";

    for (int i = 0; i < tamanho - 1; i++) {
        cout << "Elemento " << i + 1 << ": ";
        cin >> valor;
        pilha.inserir(valor);
    }

    // Mostra a pilha inicial
    cout << "\n--- PILHA INICIAL ---\n";
    pilha.mostrar();

    // Verifica se esta vazia
    cout << "\nA pilha esta vazia? ";
    cout << (pilha.estaVazia() ? "Sim" : "Nao") << endl;

    // Verifica se esta cheia
    cout << "A pilha esta cheia? ";
    cout << (pilha.estaCheia() ? "Sim" : "Nao") << endl;

    // Inserindo mais um elemento
    cout << "\nDigite um valor para inserir: ";
    cin >> valor;

    pilha.inserir(valor);

    cout << "\n--- PILHA APOS INSERCAO ---\n";
    pilha.mostrar();

    // Removendo um elemento
    cout << "\n--- REMOVENDO ELEMENTO ---\n";
    pilha.remover();

    cout << "\n--- PILHA APOS REMOCAO ---\n";
    pilha.mostrar();

    return 0;
}
